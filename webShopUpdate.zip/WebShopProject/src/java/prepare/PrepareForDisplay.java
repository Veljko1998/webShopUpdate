/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prepare;

import java.util.ArrayList;
import model.Category;
import model.Customer;
import model.Product;
import util.HQL;

/**
 *
 * @author Veljko
 */
public class PrepareForDisplay {
    public static String displayAllProducts() {
        String html;
        ArrayList<Product> allProducts = HQL.getAllProduct();
        html = "<table class='tryingTable'>";
        for(int i=0; i<allProducts.size(); i++) {
            if(i%4==0 || i==0) {
                html+="<tr>";
            }
            html+= "<td>" +
                    "<div class='imgPart'>" +
                    "<a href=\"#\">" +
                    "<img alt=\"" + allProducts.get(i).getProductName() +
                    "\" onClick=\"getProductId(" + allProducts.get(i).getProductId() +
                    ");\" src='images/" + allProducts.get(i).getProductName() + ".png'>" +
                    "</a>" +
                    "</div>" +
                    "<p>" + allProducts.get(i).getProductName() + "</p>" +
                    "<span>" + allProducts.get(i).getProductPrice() + "$</span>" +
                    "<button>CART</button>" +
                    "</td>";
            if(i!=0 && i%4==3 || (i==allProducts.size()-1)) {
                html+= "</tr>";
            }
        }
        html+= "</table>";
        return html;
    }
    /*public static String displayAllProducts() {
        String html;
        ArrayList<Product> allProducts = HQL.getAllProduct();
        html = "<table id=\"allProductsTable\" class=\"table-fill\">\n" +
                "<thead>" +
                "<tr>" + 
                 "<th onClick=\"sortTable(0)\">Product Name</th>" +
                 "<th>Description</th>" +
                 "<th onClick=\"sortTable(0)\">Price</th>" +
                 "<th>Quantity</th>" +
                 "</tr>" +
                "</thead>" +
                "<tbody class=\"table-hover\">";
        for(int i=0; i<allProducts.size(); i++) {
            html+= "<tr>"
                    + "<td>" + allProducts.get(i).getProductName() + "</td>\n"
                    + "<td>" + allProducts.get(i).getProductDescription() + "</td>\n"
                    + "<td>" + allProducts.get(i).getProductPrice() + "</td>\n"
                    + "<td>" + allProducts.get(i).getProductStock()+ "</td>\n"
                    + "</tr>";
        }
        html+= "</tbody>" +
                "</table>";
        return html;
    }*/
    public static String displaySidebar() { 
        String html;
        ArrayList<Category> allCategory = HQL.getAllCategory();
        html= "<ul class=\"brandList subList\">";
        for(int i=0; i<allCategory.size(); i++) {
            html+= "<li><a href=\"#\" onClick=\"doGetpass(" + i + ");\" id=\"" + allCategory.get(i).getCategoryName() + "\">" + allCategory.get(i).getCategoryName() + "</a></li>";
        }
        html+="</ul>";
        return html;
    }
    public static String displayProductByCategoryName(String catName) { 
        String html;
        ArrayList<Product> productByCategoryName = HQL.getProductByCategoryName(catName);
        html = "<table class='tryingTable'>";
        for(int i=0; i<productByCategoryName.size(); i++) {
            if(i%4==0 || i==0) {
                html+="<tr>";
            }
            html+= "<td>" +
                    "<div class='imgPart'>" +
                    "<a href=\"oneProduct.jsp\">" +
                    "<img alt=\"" + productByCategoryName.get(i).getProductName() +
                    "\" src='images/" + productByCategoryName.get(i).getProductName() + ".png'>" +
                    "</a>" +
                    "</div>" +
                    "<p>" + productByCategoryName.get(i).getProductName() + "</p>" +
                    "<span>" + productByCategoryName.get(i).getProductPrice() + "$</span>" +
                    "<button>CART</button>" +
                    "</td>";
            if(i!=0 && i%4==3 || (i==productByCategoryName.size()-1)) {
                html+= "</tr>";
            }
        }
        html+= "</table>";
        return html;
    }
    /*public static String displayProductByCategoryName(String catName) { 
        String html;
        ArrayList<Product> productByCategoryName = HQL.getProductByCategoryName(catName);
        html = "<table border='2px solid black'>\n" +
                "<thead>" +
                "<tr>" + 
                 "<th>Product Name</th>" +
                 "<th>Description</th>" +
                 "<th>Price</th>" +
                 "<th>Quantity</th>" +
                 "</tr>" +
                "</thead>" +
                "<tbody>";
        for(int i=0; i<productByCategoryName.size(); i++) {
            html+= "<tr>"
                    + "<td>" + productByCategoryName.get(i).getProductName() + "</td>\n"
                    + "<td>" + productByCategoryName.get(i).getProductDescription() + "</td>\n"
                    + "<td>" + productByCategoryName.get(i).getProductPrice() + "</td>\n"
                    + "<td>" + productByCategoryName.get(i).getProductStock()+ "</td>\n"
                    + "</tr>";
        }
        html+= "</tbody>"+
                "</table>";
        return html;
    }*/
    public static String displayProductByCategoryId(int id) { 
        String html;
        ArrayList<Product> productByCategoryId = HQL.getProductByCatId(id);
        html = "<table class='tryingTable'>";
        for(int i=0; i<productByCategoryId.size(); i++) {
            if(i%4==0 || i==0) {
                html+="<tr>";
            }
            html+= "<td>" +
                    "<div class='imgPart'>" +
                    "<a href=\"#\">" +
                    "<img alt=\"" + productByCategoryId.get(i).getProductName() +
                    "\" onClick=\"getProductId(" + productByCategoryId.get(i).getProductId() +
                    ");\" src='images/" + productByCategoryId.get(i).getProductName() + ".png'>" +
                    "</a>" +
                    "</div>" +
                    "<p>" + productByCategoryId.get(i).getProductName() + "</p>" +
                    "<span>" + productByCategoryId.get(i).getProductPrice() + "$</span>" +
                    "<button>CART</button>" +
                    "</td>";
            if(i!=0 && i%4==3 || (i==productByCategoryId.size()-1)) {
                html+= "</tr>";
            }
        }
        html+= "</table>";
        return html;
    }
    /*public static String displayProductByCategoryId(int id) { 
        String html;
        ArrayList<Product> productByCategoryId = HQL.getProductByCatId(id);
        html = "<table border='2px solid black'>\n" +
                "<tr>" + 
                 "<th>Product Name</th>" +
                 "<th>Description</th>" +
                 "<th>Price</th>" +
                 "<th>Quantity</th>" +
                 "</tr>";
        for(int i=0; i<productByCategoryId.size(); i++) {
            html+= "<tr>"
                    + "<td>" + productByCategoryId.get(i).getProductName() + "</td>\n"
                    + "<td>" + productByCategoryId.get(i).getProductDescription() + "</td>\n"
                    + "<td>" + productByCategoryId.get(i).getProductPrice() + "</td>\n"
                    + "<td>" + productByCategoryId.get(i).getProductStock()+ "</td>\n"
                    + "</tr>";
        }
        html+= "</table>";
        return html;
    }*/
    public static String displayAccountInfo(int id) {
        String html;
        Customer c = HQL.getCustomerById(id);
        html = "<form class='form' name='myAccountForm' id='myAccountForm' method='post' action='MyAccount'>" +
                "<input class=\"input\" id=\"myAccountFirstName\" type=\"text\" value=\"" + c.getFirstName() + "\" name=\"firstName\" required><br>" +
                "<input class=\"input\" id=\"myAccountLastName\" type=\"text\" value=\"" + c.getLastName() + "\" name=\"lastName\" required><br>" +
                "<input class=\"input\" id=\"myAccountPhoneNumber\" type=\"text\" value=\"" + c.getPhoneNumber() + "\" name=\"phoneNumber\" required><br>" +
                "<input class=\"input readonly\" id=\"myAccountEmail\" type=\"email\" value=\"" + c.getEmail() + "\" name=\"email\" readonly required><br>" +
                "<input class=\"input\" id=\"myAccountPassword\" type=\"password\" value=\"" + c.getPassword() + "\" name=\"password\" required><br>" +
                "<input class=\"input\" id=\"myAccountConfirmPassword\" type=\"password\" value=\"\" name=\"confirmPassword\" placeholder=\"Confirm your password\" required><br>" +
                "<input class=\"btn\" id=\"myAccountSubmit\" type=\"submit\" name=\"myAccountSubmit\" value=\"SAVE CHANGES\">" +
                "</form>";
        return html;
    }
    public static String displayAllProductsLike(String like) {
        String html;
        ArrayList<Product> allProductsLike = HQL.getAllProductLike("%" + like + "%");
        html = "<table class='tryingTable'>";
        for(int i=0; i<allProductsLike.size(); i++) {
            if(i%4==0 || i==0) {
                html+="<tr>";
            }
            html+= "<td>" +
                    "<div class='imgPart'>" +
                    "<a href=\"#\">" +
                    "<img href=\"oneProduct.jsp\" alt=\"" + allProductsLike.get(i).getProductName() +
                    "\" onClick='getProductId(" + allProductsLike.get(i).getProductId() +
                    ");' src='images/" + allProductsLike.get(i).getProductName() + ".png'>" +
                    "</a>" +
                    "</div>" +
                    "<p>" + allProductsLike.get(i).getProductName() + "</p>" +
                    "<span>" + allProductsLike.get(i).getProductPrice() + "$</span>" +
                    "<button>CART</button>" +
                    "</td>";
            if(i!=0 && i%4==3 || (i==allProductsLike.size()-1)) {
                html+= "</tr>";
            }
        }
        html+= "</table>";
        return html;
    }
    /*public static String displayAllProductsLike(String like) {
        String html;
        ArrayList<Product> allProductsLike = HQL.getAllProductLike("%" + like + "%");
        html = "<table border='2px solid black'>\n" +
               "<tr>" + 
                 "<th>Product Name</th>" +
                 "<th>Description</th>" +
                 "<th>Price</th>" +
                 "<th>Quantity</th>" +
               "</tr>";
        for(int i=0; i<allProductsLike.size(); i++) {
            html+= "<tr>"
                    + "<td>" + allProductsLike.get(i).getProductName() + "</td>\n"
                    + "<td>" + allProductsLike.get(i).getProductDescription() + "</td>\n"
                    + "<td>" + allProductsLike.get(i).getProductPrice() + "</td>\n"
                    + "<td>" + allProductsLike.get(i).getProductStock()+ "</td>\n"
                    + "</tr>";
        }
        html += "</table>";
        return html;
    }*/
    public static String displayProductPriceBetween(int from, int to) {
        String html;
        ArrayList<Product> allProductsBetween = HQL.getAllProductBetween(from, to);
        html = "<table class='tryingTable'>";
        for(int i=0; i<allProductsBetween.size(); i++) {
            if(i%4==0 || i==0) {
                html+="<tr>";
            }
            html+= "<td>" +
                    "<div class='imgPart'>" +
                    "<a href=\"#\">" +
                    "<img href=\"oneProduct.jsp\" alt=\"" + allProductsBetween.get(i).getProductName() +
                    "\" onClick='getProductId(" + allProductsBetween.get(i).getProductId() +
                    ");' src='images/" + allProductsBetween.get(i).getProductName() + ".png'>" +
                    "</a>" +
                    "</div>" +
                    "<p>" + allProductsBetween.get(i).getProductName() + "</p>" +
                    "<span>" + allProductsBetween.get(i).getProductPrice() + "$</span>" +
                    "<button>CART</button>" +
                    "</td>";
            if(i!=0 && i%4==3 || (i==allProductsBetween.size()-1)) {
                html+= "</tr>";
            }
        }
        html+= "</table>";
        return html;
    }
    /*public static String displayProductPriceBetween(int from, int to) {
        String html;
        ArrayList<Product> allProductsBetween = HQL.getAllProductBetween(from, to);
        html = "<table border='2px solid black'>\n" +
               "<tr>" + 
                 "<th>Product Name</th>" +
                 "<th>Description</th>" +
                 "<th>Price</th>" +
                 "<th>Quantity</th>" +
               "</tr>";
        for(int i=0; i<allProductsBetween.size(); i++) {
            html+= "<tr>"
                    + "<td>" + allProductsBetween.get(i).getProductName() + "</td>\n"
                    + "<td>" + allProductsBetween.get(i).getProductDescription() + "</td>\n"
                    + "<td>" + allProductsBetween.get(i).getProductPrice() + "</td>\n"
                    + "<td>" + allProductsBetween.get(i).getProductStock()+ "</td>\n"
                    + "</tr>";
        }
        html+= "</table>";
        return html;
    }*/
    public static String displayProductById(int id) {
        String html;
        Product p = HQL.getProductById(id);
        html = "<table border= 1px solid black>" +
                "<tr>" +
                    "<td><img src='images/"+ p.getProductName() +".png'></td>" +
                    "<td>" + p.getProductName() + "</td>" +
                    "<td>" + p.getProductPrice()+ "</td>" +
                "</tr>" +
                "</table>";
        
        return html;
    }
}
