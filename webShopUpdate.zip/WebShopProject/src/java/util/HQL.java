/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

import java.util.ArrayList;
import model.Category;
import model.Customer;
import model.Product;
import org.hibernate.Query;
import org.hibernate.Session;
import prepare.PrepareForDisplay;

/**
 *
 * @author Veljko
 */
public class HQL {
    public static ArrayList<Product> getProductByCatId(int catId) {
        try{
        Session session = HibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        Query byCatId = session.createQuery("from Product p where p.categoryId=?");
        byCatId.setInteger(0, catId);
        ArrayList<Product> productsByCatId = new ArrayList(byCatId.list());
        session.getTransaction().commit();
        return productsByCatId;
        } catch(Exception ex) {
            return getAllProduct();
        }
    }
    public static ArrayList<Product> getAllProduct() {
        try {
        Session session = HibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        Query selectAllProducts = session.createQuery("from Product");
        ArrayList<Product> allProducts = new ArrayList(selectAllProducts.list());
        session.getTransaction().commit();
        return allProducts;
        } catch(Exception ex) {
            return new ArrayList();
        }
    }
    public static ArrayList<Category> getAllCategory() {
        try {
        Session session = HibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        Query selectAllCategory = session.createQuery("from Category");
        ArrayList<Category> allCategory = new ArrayList(selectAllCategory.list());
        session.getTransaction().commit();
        return allCategory;
        } catch (Exception ex) {
            return new ArrayList();
        }
    }
    public static ArrayList<Product> getProductByCategoryName(String catName) {
        try {
        Session session = HibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        Query byCatName = session.createQuery("from Product p where p.categoryName=?");
        byCatName.setString(0, catName);
        ArrayList<Product> productsByCatName = new ArrayList(byCatName.list());
        session.getTransaction().commit();
        return productsByCatName;
        } catch(Exception ex) {
            return getAllProduct();
        }
    }
    public static Customer getCustomerById(int id) {
        try {
        Session session = HibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        Query byCustomerId = session.createQuery("from Customer c where c.id=?");
        byCustomerId.setInteger(0, id);
        Customer c = (Customer) byCustomerId.uniqueResult();
        session.getTransaction().commit();
        return c;
        } catch (Exception ex) {
            return new Customer();
        }
    }
    public static ArrayList<Product> getAllProductLike(String like) {
        try {
        Session session = HibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        Query productsLike = session.createQuery("from Product p where p.productName like ?");
        productsLike.setString(0, like);
        ArrayList<Product> allProductsLike = new ArrayList(productsLike.list());
        session.getTransaction().commit();
        return allProductsLike;
        } catch(Exception ex) {
            return getAllProduct();
        }
    }
    public static ArrayList<Product> getAllProductBetween(int from, int to) {
        try {
        if(to<=from) {
            return getAllProduct();
        }
        Session session = HibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        Query productsBetween= session.createQuery("from Product p where p.productPrice between ? and ?");
        productsBetween.setInteger(0, from);
        productsBetween.setInteger(1, to);
        ArrayList<Product> allProductsBetween = new ArrayList(productsBetween.list());
        session.getTransaction().commit();
        return allProductsBetween;
        } catch(Exception ex) {
            return getAllProduct();
        }
    }
    public static Product getProductById(int id) {
        try {
        Session session = HibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        Query byProductId = session.createQuery("from Product p where p.productId=?");
        byProductId.setInteger(0, id);
        Product p = (Product) byProductId.uniqueResult();
        session.getTransaction().commit();
        return p;
        } catch(Exception ex) {
            return new Product();
        }
    }
}
